//
//  VC1.swift
//  sopt_ios_first_hw
//
//  Created by shineeseo on 2018. 10. 4..
//  Copyright © 2018년 shineeseo. All rights reserved.
//

import UIKit

class VC1: ViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func unwindToVC1(segue:UIStoryboardSegue){}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
