//
//  ViewController.swift
//  sopt_ios_first_hw
//
//  Created by shineeseo on 2018. 10. 4..
//  Copyright © 2018년 shineeseo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

